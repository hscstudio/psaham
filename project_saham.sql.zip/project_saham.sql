-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2015 at 11:25 PM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project_saham`
--

-- --------------------------------------------------------

--
-- Table structure for table `asset`
--

DROP TABLE IF EXISTS `asset`;
CREATE TABLE IF NOT EXISTS `asset` (
  `TGL` date NOT NULL,
  `KAS_BANK` decimal(15,2) NOT NULL,
  `TRAN_JALAN` decimal(15,2) NOT NULL,
  `INV_LAIN` decimal(15,2) NOT NULL,
  `STOK_SAHAM` decimal(15,2) NOT NULL,
  `HUTANG` decimal(15,2) NOT NULL,
  `HUT_LANCAR` decimal(15,2) NOT NULL,
  `MODAL` decimal(15,2) NOT NULL,
  `CAD_LABA` decimal(15,2) NOT NULL,
  `LABA_JALAN` decimal(15,2) NOT NULL,
  `UNIT` decimal(15,2) NOT NULL,
  `NAV` decimal(15,2) NOT NULL,
  `TUMBUH` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `assetat`
--

DROP TABLE IF EXISTS `assetat`;
CREATE TABLE IF NOT EXISTS `assetat` (
  `TGL` date NOT NULL,
  `KAS_BANK` decimal(15,2) NOT NULL,
  `TRAN_JALAN` decimal(15,2) NOT NULL,
  `INV_LAIN` decimal(15,2) NOT NULL,
  `STOK_SAHAM` decimal(15,2) NOT NULL,
  `HUTANG` decimal(15,2) NOT NULL,
  `HUT_LAIN` decimal(15,2) NOT NULL,
  `MODAL` decimal(15,2) NOT NULL,
  `CAD_LABA` decimal(15,2) NOT NULL,
  `LABA_JALAN` decimal(15,2) NOT NULL,
  `UNITAT` decimal(15,2) NOT NULL,
  `NAVAT` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

DROP TABLE IF EXISTS `auth_assignment`;
CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('Administrator', '1', 1444551624);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

DROP TABLE IF EXISTS `auth_item`;
CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('Administrator', 1, NULL, NULL, NULL, 1444550047, 1444551593);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

DROP TABLE IF EXISTS `auth_item_child`;
CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

DROP TABLE IF EXISTS `auth_rule`;
CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `detemiten`
--

DROP TABLE IF EXISTS `detemiten`;
CREATE TABLE IF NOT EXISTS `detemiten` (
  `TGL` date NOT NULL,
  `EMITEN_KODE` varchar(8) NOT NULL,
  `JMLLOT` decimal(15,2) NOT NULL,
  `JMLSAHAM` decimal(15,2) NOT NULL,
  `SALDO` decimal(15,2) NOT NULL,
  `HARGA` decimal(15,2) NOT NULL,
  `TGLAKHIR` date NOT NULL,
  `JMLLOTB` decimal(15,2) NOT NULL,
  `SALDOB` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `emiten`
--

DROP TABLE IF EXISTS `emiten`;
CREATE TABLE IF NOT EXISTS `emiten` (
  `KODE` varchar(8) NOT NULL,
  `NAMA` varchar(50) NOT NULL,
  `JMLLOT` decimal(15,2) NOT NULL,
  `JMLSAHAM` decimal(15,2) NOT NULL,
  `SALDO` decimal(15,2) NOT NULL,
  `HARGA` decimal(15,2) NOT NULL,
  `SALDOR1` decimal(15,2) NOT NULL,
  `JMLLOTB` decimal(15,2) NOT NULL,
  `SALDOB` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emiten`
--

INSERT INTO `emiten` (`KODE`, `NAMA`, `JMLLOT`, `JMLSAHAM`, `SALDO`, `HARGA`, `SALDOR1`, `JMLLOTB`, `SALDOB`) VALUES
('AKRA', 'ANEKA KIMIA RAYA', '25.00', '37500.00', '50000.00', '1200.00', '1.33', '200.00', '250.00');

-- --------------------------------------------------------

--
-- Table structure for table `indikator`
--

DROP TABLE IF EXISTS `indikator`;
CREATE TABLE IF NOT EXISTS `indikator` (
  `TGL` date NOT NULL,
  `NAMA` varchar(100) NOT NULL,
  `NAVAT` decimal(15,2) NOT NULL,
  `NAV` decimal(15,2) NOT NULL,
  `TUMBUH` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `komisi`
--

DROP TABLE IF EXISTS `komisi`;
CREATE TABLE IF NOT EXISTS `komisi` (
  `KOM_BELI` decimal(15,2) NOT NULL,
  `KOM_JUAL` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `komisi`
--

INSERT INTO `komisi` (`KOM_BELI`, `KOM_JUAL`) VALUES
('0.30', '0.35');

-- --------------------------------------------------------

--
-- Table structure for table `lotshare`
--

DROP TABLE IF EXISTS `lotshare`;
CREATE TABLE IF NOT EXISTS `lotshare` (
  `JML_LBRSAHAM` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lotshare`
--

INSERT INTO `lotshare` (`JML_LBRSAHAM`) VALUES
('1500.00');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

DROP TABLE IF EXISTS `menu`;
CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `route` varchar(256) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

DROP TABLE IF EXISTS `migration`;
CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1444546475),
('m130524_201442_init', 1444547002),
('m140506_102106_rbac_init', 1444549760),
('m140602_111327_create_menu_table', 1444549977);

-- --------------------------------------------------------

--
-- Table structure for table `note`
--

DROP TABLE IF EXISTS `note`;
CREATE TABLE IF NOT EXISTS `note` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `note`
--

INSERT INTO `note` (`id`, `title`, `content`, `created_at`, `updated_at`) VALUES
(1, 'Test ting ajah', 'Lorem ipsum sit dolor amet\r\n1. sss\r\n2. ssss', 1445004022, 1445030081),
(2, 'sfafa', '-	Data yg ditampilkan didapat dari TABLE EMITEN.  Data dari table EMITEN dimana JMLLOT = 0.\r\n-	Field inputan di bagian paling atas itu untuk SEARCH KODE EMITEN.\r\n-	Tampilan data per page default 20. Bisa diubah jd 10/20/30/50/100 per page.\r\n-	Tampilkan jumlah data keseluruhan.\r\n-	Refresh data dibuat otomatis begitu ada data baru. (tidak perlu tekan tombol refresh lagi)\r\n-	Bisa eksport ke excel, pdf, html sesuai tampilan.\r\n', 1445030116, 1445030425);

-- --------------------------------------------------------

--
-- Table structure for table `paramfund`
--

DROP TABLE IF EXISTS `paramfund`;
CREATE TABLE IF NOT EXISTS `paramfund` (
  `EMITEN_KODE` varchar(8) NOT NULL,
  `TAHUN` varchar(4) NOT NULL,
  `TRIWULAN` varchar(5) NOT NULL,
  `BV` decimal(15,2) NOT NULL,
  `P_BV` decimal(15,2) NOT NULL DEFAULT '0.00',
  `EPS` decimal(15,2) NOT NULL,
  `P_EPS` decimal(15,2) NOT NULL DEFAULT '0.00',
  `PBV` decimal(15,2) NOT NULL,
  `PER` decimal(15,2) NOT NULL,
  `DER` decimal(15,2) NOT NULL,
  `SHARE` decimal(15,2) NOT NULL,
  `HARGA` decimal(15,2) NOT NULL,
  `CE` decimal(15,2) NOT NULL,
  `CA` decimal(15,2) NOT NULL,
  `TA` decimal(15,2) NOT NULL,
  `TE` decimal(15,2) NOT NULL,
  `CL` decimal(15,2) NOT NULL,
  `TL` decimal(15,2) NOT NULL,
  `SALES` decimal(15,2) NOT NULL,
  `NI` decimal(15,2) NOT NULL,
  `ROE` decimal(15,2) NOT NULL,
  `ROA` decimal(15,2) NOT NULL,
  `P_TE` decimal(15,2) NOT NULL DEFAULT '0.00',
  `P_SALES` decimal(15,2) NOT NULL DEFAULT '0.00',
  `P_NI` decimal(15,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

DROP TABLE IF EXISTS `pembelian`;
CREATE TABLE IF NOT EXISTS `pembelian` (
  `NOMOR` varchar(6) NOT NULL,
  `TGL` date NOT NULL,
  `JMLLOT` decimal(15,2) NOT NULL,
  `JMLSAHAM` decimal(15,2) NOT NULL,
  `HARGA` decimal(15,2) NOT NULL,
  `KOM_BELI` decimal(15,2) NOT NULL,
  `TOTAL_BELI` decimal(15,2) NOT NULL,
  `EMITEN_KODE` varchar(8) DEFAULT NULL,
  `SECURITAS_KODE` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`NOMOR`, `TGL`, `JMLLOT`, `JMLSAHAM`, `HARGA`, `KOM_BELI`, `TOTAL_BELI`, `EMITEN_KODE`, `SECURITAS_KODE`) VALUES
('000001', '2015-10-14', '2.00', '3000.00', '1000.00', '0.30', '0.00', 'AKRA', 'NMQ'),
('000002', '2015-10-14', '20.00', '30000.00', '1250.00', '0.30', '0.00', 'AKRA', 'NMQ');

-- --------------------------------------------------------

--
-- Table structure for table `securitas`
--

DROP TABLE IF EXISTS `securitas`;
CREATE TABLE IF NOT EXISTS `securitas` (
  `KODE` varchar(8) NOT NULL,
  `NAMA` varchar(30) NOT NULL,
  `ALAMAT` varchar(50) NOT NULL,
  `TELP` varchar(15) NOT NULL,
  `CP` varchar(20) NOT NULL,
  `HP` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `securitas`
--

INSERT INTO `securitas` (`KODE`, `NAMA`, `ALAMAT`, `TELP`, `CP`, `HP`) VALUES
('NMQ', 'Nuansa Madinatul Qu''ran', 'Jl Cepit Raya No 12 Kav 19 Kp Sawah', '0217526261', 'Hafid Mukhlasin', '081559915720');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'admin', 'A9NNIGDc36nAQUiQVbMe3CR9xZ_8x489', '$2y$13$qM.KkhAeUihQWy53J42rN.Ack0xz6pgfaV3nj5IeawETepPovD.ey', NULL, 'admin2@gmail.com', 10, 1444548165, 1444981611);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `asset`
--
ALTER TABLE `asset`
  ADD PRIMARY KEY (`TGL`);

--
-- Indexes for table `assetat`
--
ALTER TABLE `assetat`
  ADD PRIMARY KEY (`TGL`);

--
-- Indexes for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`);

--
-- Indexes for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD PRIMARY KEY (`name`), ADD KEY `rule_name` (`rule_name`), ADD KEY `idx-auth_item-type` (`type`);

--
-- Indexes for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`), ADD KEY `child` (`child`);

--
-- Indexes for table `auth_rule`
--
ALTER TABLE `auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `detemiten`
--
ALTER TABLE `detemiten`
  ADD PRIMARY KEY (`EMITEN_KODE`,`TGL`);

--
-- Indexes for table `emiten`
--
ALTER TABLE `emiten`
  ADD PRIMARY KEY (`KODE`);

--
-- Indexes for table `indikator`
--
ALTER TABLE `indikator`
  ADD PRIMARY KEY (`TGL`,`NAMA`);

--
-- Indexes for table `komisi`
--
ALTER TABLE `komisi`
  ADD PRIMARY KEY (`KOM_BELI`);

--
-- Indexes for table `lotshare`
--
ALTER TABLE `lotshare`
  ADD PRIMARY KEY (`JML_LBRSAHAM`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`), ADD KEY `parent` (`parent`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `note`
--
ALTER TABLE `note`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paramfund`
--
ALTER TABLE `paramfund`
  ADD PRIMARY KEY (`EMITEN_KODE`,`TAHUN`,`TRIWULAN`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`NOMOR`), ADD KEY `FK_emiten_pembelian` (`EMITEN_KODE`), ADD KEY `FK_securitas_pembelian` (`SECURITAS_KODE`);

--
-- Indexes for table `securitas`
--
ALTER TABLE `securitas`
  ADD PRIMARY KEY (`KODE`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `username` (`username`), ADD UNIQUE KEY `email` (`email`), ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `note`
--
ALTER TABLE `note`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `detemiten`
--
ALTER TABLE `detemiten`
ADD CONSTRAINT `FK_emiten_detemiten` FOREIGN KEY (`EMITEN_KODE`) REFERENCES `emiten` (`KODE`);

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `menu` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `paramfund`
--
ALTER TABLE `paramfund`
ADD CONSTRAINT `FK_emiten_paramfund` FOREIGN KEY (`EMITEN_KODE`) REFERENCES `emiten` (`KODE`);

--
-- Constraints for table `pembelian`
--
ALTER TABLE `pembelian`
ADD CONSTRAINT `FK_emiten_pembelian` FOREIGN KEY (`EMITEN_KODE`) REFERENCES `emiten` (`KODE`),
ADD CONSTRAINT `FK_securitas_pembelian` FOREIGN KEY (`SECURITAS_KODE`) REFERENCES `securitas` (`KODE`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
