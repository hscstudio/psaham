-- phpMyAdmin SQL Dump
-- version 4.3.11
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 26, 2015 at 11:48 AM
-- Server version: 5.6.24
-- PHP Version: 5.6.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `project_saham`
--

-- --------------------------------------------------------

--
-- Table structure for table `asset`
--

CREATE TABLE IF NOT EXISTS `asset` (
  `TGL` date NOT NULL,
  `KAS_BANK` decimal(15,2) NOT NULL,
  `TRAN_JALAN` decimal(15,2) NOT NULL,
  `INV_LAIN` decimal(15,2) NOT NULL,
  `STOK_SAHAM` decimal(15,2) NOT NULL,
  `HUTANG` decimal(15,2) NOT NULL,
  `HUT_LANCAR` decimal(15,2) NOT NULL,
  `MODAL` decimal(15,2) NOT NULL,
  `CAD_LABA` decimal(15,2) NOT NULL,
  `LABA_JALAN` decimal(15,2) NOT NULL,
  `UNIT` decimal(15,2) NOT NULL,
  `NAV` decimal(15,2) NOT NULL,
  `TUMBUH` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `asset`
--

INSERT INTO `asset` (`TGL`, `KAS_BANK`, `TRAN_JALAN`, `INV_LAIN`, `STOK_SAHAM`, `HUTANG`, `HUT_LANCAR`, `MODAL`, `CAD_LABA`, `LABA_JALAN`, `UNIT`, `NAV`, `TUMBUH`) VALUES
('2015-10-20', '2000000.00', '350000.00', '150000.00', '250000.00', '200000.00', '30000.00', '2000000.00', '25000.00', '50000.00', '2.00', '1260000.00', '-12.50'),
('2015-10-26', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `assetat`
--

CREATE TABLE IF NOT EXISTS `assetat` (
  `TGL` date NOT NULL,
  `KAS_BANK` decimal(15,2) NOT NULL,
  `TRAN_JALAN` decimal(15,2) NOT NULL,
  `INV_LAIN` decimal(15,2) NOT NULL,
  `STOK_SAHAM` decimal(15,2) NOT NULL,
  `HUTANG` decimal(15,2) NOT NULL,
  `HUT_LAIN` decimal(15,2) NOT NULL,
  `MODAL` decimal(15,2) NOT NULL,
  `CAD_LABA` decimal(15,2) NOT NULL,
  `LABA_JALAN` decimal(15,2) NOT NULL,
  `UNITAT` decimal(15,2) NOT NULL,
  `NAVAT` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `assetat`
--

INSERT INTO `assetat` (`TGL`, `KAS_BANK`, `TRAN_JALAN`, `INV_LAIN`, `STOK_SAHAM`, `HUTANG`, `HUT_LAIN`, `MODAL`, `CAD_LABA`, `LABA_JALAN`, `UNITAT`, `NAVAT`) VALUES
('2015-01-01', '1000000.00', '250000.00', '100000.00', '200000.00', '100000.00', '10000.00', '2000000.00', '250000.00', '50000.00', '1.00', '1440000.00');

-- --------------------------------------------------------

--
-- Table structure for table `auth_assignment`
--

CREATE TABLE IF NOT EXISTS `auth_assignment` (
  `item_name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `user_id` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `created_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_assignment`
--

INSERT INTO `auth_assignment` (`item_name`, `user_id`, `created_at`) VALUES
('Administrator', '1', 1445812879);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item`
--

CREATE TABLE IF NOT EXISTS `auth_item` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` int(11) NOT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `rule_name` varchar(64) COLLATE utf8_unicode_ci DEFAULT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item`
--

INSERT INTO `auth_item` (`name`, `type`, `description`, `rule_name`, `data`, `created_at`, `updated_at`) VALUES
('/asset/*', 2, NULL, NULL, NULL, 1445812822, 1445812822),
('/emiten/*', 2, NULL, NULL, NULL, 1445812823, 1445812823),
('/history-emiten/*', 2, NULL, NULL, NULL, 1445812824, 1445812824),
('/history-paramfund/*', 2, NULL, NULL, NULL, 1445812825, 1445812825),
('/indikator/*', 2, NULL, NULL, NULL, 1445815388, 1445815388),
('/komisi/*', 2, NULL, NULL, NULL, 1445812826, 1445812826),
('/mimin/role/*', 2, NULL, NULL, NULL, 1445812832, 1445812832),
('/mimin/route/*', 2, NULL, NULL, NULL, 1445812833, 1445812833),
('/mimin/user/*', 2, NULL, NULL, NULL, 1445812834, 1445812834),
('/note/*', 2, NULL, NULL, NULL, 1445812835, 1445812835),
('/paramfund/*', 2, NULL, NULL, NULL, 1445812836, 1445812836),
('/pembelian/*', 2, NULL, NULL, NULL, 1445812837, 1445812837),
('/securitas/*', 2, NULL, NULL, NULL, 1445812838, 1445812838),
('Administrator', 1, NULL, NULL, NULL, 1445812784, 1445812784);

-- --------------------------------------------------------

--
-- Table structure for table `auth_item_child`
--

CREATE TABLE IF NOT EXISTS `auth_item_child` (
  `parent` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `child` varchar(64) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `auth_item_child`
--

INSERT INTO `auth_item_child` (`parent`, `child`) VALUES
('Administrator', '/asset/*'),
('Administrator', '/emiten/*'),
('Administrator', '/history-emiten/*'),
('Administrator', '/history-paramfund/*'),
('Administrator', '/indikator/*'),
('Administrator', '/komisi/*'),
('Administrator', '/mimin/role/*'),
('Administrator', '/mimin/route/*'),
('Administrator', '/mimin/user/*'),
('Administrator', '/note/*'),
('Administrator', '/paramfund/*'),
('Administrator', '/pembelian/*'),
('Administrator', '/securitas/*');

-- --------------------------------------------------------

--
-- Table structure for table `auth_rule`
--

CREATE TABLE IF NOT EXISTS `auth_rule` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `data` text COLLATE utf8_unicode_ci,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `detemiten`
--

CREATE TABLE IF NOT EXISTS `detemiten` (
  `TGL` date NOT NULL,
  `EMITEN_KODE` varchar(8) NOT NULL,
  `JMLLOT` decimal(15,2) NOT NULL,
  `JMLSAHAM` decimal(15,2) NOT NULL,
  `SALDO` decimal(15,2) NOT NULL,
  `HARGA` decimal(15,2) NOT NULL,
  `TGLAKHIR` date NOT NULL,
  `JMLLOTB` decimal(15,2) NOT NULL,
  `SALDOB` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `emiten`
--

CREATE TABLE IF NOT EXISTS `emiten` (
  `KODE` varchar(8) NOT NULL,
  `NAMA` varchar(50) NOT NULL,
  `JMLLOT` decimal(15,2) NOT NULL,
  `JMLSAHAM` decimal(15,2) NOT NULL,
  `SALDO` decimal(15,2) NOT NULL,
  `HARGA` decimal(15,2) NOT NULL,
  `SALDOR1` decimal(15,2) NOT NULL,
  `JMLLOTB` decimal(15,2) NOT NULL,
  `SALDOB` decimal(15,2) NOT NULL,
  `last_update` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emiten`
--

INSERT INTO `emiten` (`KODE`, `NAMA`, `JMLLOT`, `JMLSAHAM`, `SALDO`, `HARGA`, `SALDOR1`, `JMLLOTB`, `SALDOB`, `last_update`) VALUES
('AKRA', 'ANEKA KIMIA RAYA', '215.00', '322500.00', '50000.00', '1200.00', '1.33', '200.00', '250.00', 1445846129),
('FISTA', 'FIRS TANK', '1.00', '1500.00', '1.00', '1.00', '0.00', '2.00', '1.00', 1445851476),
('XYZ', 'asdasdasda', '2.00', '3000.00', '2.00', '2.00', '0.00', '2.00', '2.00', 1445852943);

-- --------------------------------------------------------

--
-- Table structure for table `indikator`
--

CREATE TABLE IF NOT EXISTS `indikator` (
  `TGL` date NOT NULL,
  `NAMA` varchar(100) NOT NULL,
  `NAVAT` decimal(15,2) NOT NULL,
  `NAV` decimal(15,2) NOT NULL,
  `TUMBUH` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `indikator`
--

INSERT INTO `indikator` (`TGL`, `NAMA`, `NAVAT`, `NAV`, `TUMBUH`) VALUES
('2015-10-20', 'IndikatorA', '1.00', '21.00', '20.00'),
('2015-10-20', 'IndikatorB', '2.00', '3.00', '0.50');

-- --------------------------------------------------------

--
-- Table structure for table `komisi`
--

CREATE TABLE IF NOT EXISTS `komisi` (
  `KOM_BELI` decimal(15,2) NOT NULL,
  `KOM_JUAL` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `komisi`
--

INSERT INTO `komisi` (`KOM_BELI`, `KOM_JUAL`) VALUES
('0.30', '0.35');

-- --------------------------------------------------------

--
-- Table structure for table `lotshare`
--

CREATE TABLE IF NOT EXISTS `lotshare` (
  `JML_LBRSAHAM` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `lotshare`
--

INSERT INTO `lotshare` (`JML_LBRSAHAM`) VALUES
('1500.00');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE IF NOT EXISTS `menu` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `parent` int(11) DEFAULT NULL,
  `route` varchar(256) DEFAULT NULL,
  `order` int(11) DEFAULT NULL,
  `data` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE IF NOT EXISTS `migration` (
  `version` varchar(180) NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1444546475),
('m130524_201442_init', 1444547002),
('m140506_102106_rbac_init', 1444549760),
('m140602_111327_create_menu_table', 1444549977);

-- --------------------------------------------------------

--
-- Table structure for table `note`
--

CREATE TABLE IF NOT EXISTS `note` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` int(11) DEFAULT NULL,
  `updated_at` int(11) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `note`
--

INSERT INTO `note` (`id`, `title`, `content`, `created_at`, `updated_at`) VALUES
(1, 'Test ting ajah', 'Lorem ipsum sit dolor amet\r\n1. sss\r\n2. ssss', 1445004022, 1445030081),
(2, 'sfafa', '-	Data yg ditampilkan didapat dari TABLE EMITEN.  Data dari table EMITEN dimana JMLLOT = 0.\r\n-	Field inputan di bagian paling atas itu untuk SEARCH KODE EMITEN.\r\n-	Tampilan data per page default 20. Bisa diubah jd 10/20/30/50/100 per page.\r\n-	Tampilkan jumlah data keseluruhan.\r\n-	Refresh data dibuat otomatis begitu ada data baru. (tidak perlu tekan tombol refresh lagi)\r\n-	Bisa eksport ke excel, pdf, html sesuai tampilan.\r\n', 1445030116, 1445729363);

-- --------------------------------------------------------

--
-- Table structure for table `paramfund`
--

CREATE TABLE IF NOT EXISTS `paramfund` (
  `EMITEN_KODE` varchar(8) NOT NULL,
  `TAHUN` varchar(4) NOT NULL,
  `TRIWULAN` varchar(5) NOT NULL,
  `BV` decimal(15,2) NOT NULL,
  `P_BV` decimal(15,2) NOT NULL DEFAULT '0.00',
  `EPS` decimal(15,2) NOT NULL,
  `P_EPS` decimal(15,2) NOT NULL DEFAULT '0.00',
  `PBV` decimal(15,2) NOT NULL,
  `PER` decimal(15,2) NOT NULL,
  `DER` decimal(15,2) NOT NULL,
  `SHARE` decimal(15,2) NOT NULL,
  `HARGA` decimal(15,2) NOT NULL,
  `CE` decimal(15,2) NOT NULL,
  `CA` decimal(15,2) NOT NULL,
  `TA` decimal(15,2) NOT NULL,
  `TE` decimal(15,2) NOT NULL,
  `CL` decimal(15,2) NOT NULL,
  `TL` decimal(15,2) NOT NULL,
  `SALES` decimal(15,2) NOT NULL,
  `NI` decimal(15,2) NOT NULL,
  `ROE` decimal(15,2) NOT NULL,
  `ROA` decimal(15,2) NOT NULL,
  `P_TE` decimal(15,2) NOT NULL DEFAULT '0.00',
  `P_SALES` decimal(15,2) NOT NULL DEFAULT '0.00',
  `P_NI` decimal(15,2) NOT NULL DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `paramfund`
--

INSERT INTO `paramfund` (`EMITEN_KODE`, `TAHUN`, `TRIWULAN`, `BV`, `P_BV`, `EPS`, `P_EPS`, `PBV`, `PER`, `DER`, `SHARE`, `HARGA`, `CE`, `CA`, `TA`, `TE`, `CL`, `TL`, `SALES`, `NI`, `ROE`, `ROA`, `P_TE`, `P_SALES`, `P_NI`) VALUES
('AKRA', '2014', 'IV', '100.00', '0.00', '1.00', '0.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '0.00', '0.00', '0.00'),
('AKRA', '2015', 'IV', '75.00', '-0.25', '2.00', '0.00', '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', '2.00', '0.00', '0.00', '0.00'),
('FISTA', '2015', 'IV', '1.00', '0.00', '1.00', '0.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '1.00', '0.00', '0.00', '0.00'),
('XYZ', '2015', 'III', '3.00', '0.00', '3.00', '0.00', '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', '3.00', '0.00', '0.00', '0.00');

-- --------------------------------------------------------

--
-- Table structure for table `pembelian`
--

CREATE TABLE IF NOT EXISTS `pembelian` (
  `NOMOR` varchar(6) NOT NULL,
  `TGL` date NOT NULL,
  `JMLLOT` decimal(15,2) NOT NULL,
  `JMLSAHAM` decimal(15,2) NOT NULL,
  `HARGA` decimal(15,2) NOT NULL,
  `KOM_BELI` decimal(15,2) NOT NULL,
  `TOTAL_BELI` decimal(15,2) NOT NULL,
  `EMITEN_KODE` varchar(8) DEFAULT NULL,
  `SECURITAS_KODE` varchar(8) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pembelian`
--

INSERT INTO `pembelian` (`NOMOR`, `TGL`, `JMLLOT`, `JMLSAHAM`, `HARGA`, `KOM_BELI`, `TOTAL_BELI`, `EMITEN_KODE`, `SECURITAS_KODE`) VALUES
('000001', '2015-10-14', '2.00', '3000.00', '1000.00', '0.30', '0.00', 'AKRA', 'NMQ'),
('000002', '2015-10-14', '20.00', '30000.00', '1250.00', '0.30', '0.00', 'AKRA', 'NMQ'),
('000003', '2015-10-26', '1.00', '1500.00', '1.00', '0.30', '0.00', 'FISTA', 'NMQ');

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE IF NOT EXISTS `route` (
  `name` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `alias` varchar(64) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(64) COLLATE utf8_unicode_ci DEFAULT 'default',
  `status` tinyint(1) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`name`, `alias`, `type`, `status`) VALUES
('/*', '*', '', 0),
('/asset/*', '*', 'asset', 1),
('/asset/create', 'create', 'asset', 1),
('/asset/delete', 'delete', 'asset', 1),
('/asset/export-excel', 'export-excel', 'asset', 1),
('/asset/export-excel-detail', 'export-excel-detail', 'asset', 1),
('/asset/export-pdf', 'export-pdf', 'asset', 1),
('/asset/export-pdf-detail', 'export-pdf-detail', 'asset', 1),
('/asset/index', 'index', 'asset', 1),
('/asset/update', 'update', 'asset', 1),
('/asset/view', 'view', 'asset', 1),
('/debug/*', '*', 'debug', 0),
('/debug/default/*', '*', 'debug/default', 0),
('/debug/default/db-explain', 'db-explain', 'debug/default', 0),
('/debug/default/download-mail', 'download-mail', 'debug/default', 0),
('/debug/default/index', 'index', 'debug/default', 0),
('/debug/default/toolbar', 'toolbar', 'debug/default', 0),
('/debug/default/view', 'view', 'debug/default', 0),
('/emiten/*', '*', 'emiten', 1),
('/emiten/create', 'create', 'emiten', 1),
('/emiten/delete', 'delete', 'emiten', 1),
('/emiten/export-excel', 'export-excel', 'emiten', 1),
('/emiten/export-pdf', 'export-pdf', 'emiten', 1),
('/emiten/index', 'index', 'emiten', 1),
('/emiten/update', 'update', 'emiten', 1),
('/emiten/view', 'view', 'emiten', 1),
('/gii/*', '*', 'gii', 0),
('/gii/default/*', '*', 'gii/default', 0),
('/gii/default/action', 'action', 'gii/default', 0),
('/gii/default/diff', 'diff', 'gii/default', 0),
('/gii/default/index', 'index', 'gii/default', 0),
('/gii/default/preview', 'preview', 'gii/default', 0),
('/gii/default/view', 'view', 'gii/default', 0),
('/gridview/*', '*', 'gridview', 0),
('/gridview/export/*', '*', 'gridview/export', 0),
('/gridview/export/download', 'download', 'gridview/export', 0),
('/history-emiten/*', '*', 'history-emiten', 1),
('/history-emiten/create', 'create', 'history-emiten', 1),
('/history-emiten/delete', 'delete', 'history-emiten', 1),
('/history-emiten/export-excel', 'export-excel', 'history-emiten', 1),
('/history-emiten/export-pdf', 'export-pdf', 'history-emiten', 1),
('/history-emiten/index', 'index', 'history-emiten', 1),
('/history-emiten/sse', 'sse', 'history-emiten', 1),
('/history-emiten/update', 'update', 'history-emiten', 1),
('/history-emiten/view', 'view', 'history-emiten', 1),
('/history-paramfund/*', '*', 'history-paramfund', 1),
('/history-paramfund/export-excel', 'export-excel', 'history-paramfund', 1),
('/history-paramfund/export-pdf', 'export-pdf', 'history-paramfund', 1),
('/history-paramfund/index', 'index', 'history-paramfund', 1),
('/indikator/*', '*', 'indikator', 1),
('/indikator/create', 'create', 'indikator', 1),
('/indikator/delete', 'delete', 'indikator', 1),
('/indikator/index', 'index', 'indikator', 1),
('/indikator/update', 'update', 'indikator', 1),
('/indikator/view', 'view', 'indikator', 1),
('/komisi/*', '*', 'komisi', 1),
('/komisi/index', 'index', 'komisi', 1),
('/mimin/*', '*', 'mimin', 0),
('/mimin/role/*', '*', 'mimin/role', 1),
('/mimin/role/create', 'create', 'mimin/role', 1),
('/mimin/role/delete', 'delete', 'mimin/role', 1),
('/mimin/role/index', 'index', 'mimin/role', 1),
('/mimin/role/permission', 'permission', 'mimin/role', 1),
('/mimin/role/update', 'update', 'mimin/role', 1),
('/mimin/role/view', 'view', 'mimin/role', 1),
('/mimin/route/*', '*', 'mimin/route', 1),
('/mimin/route/create', 'create', 'mimin/route', 1),
('/mimin/route/delete', 'delete', 'mimin/route', 1),
('/mimin/route/generate', 'generate', 'mimin/route', 1),
('/mimin/route/index', 'index', 'mimin/route', 1),
('/mimin/route/update', 'update', 'mimin/route', 1),
('/mimin/route/view', 'view', 'mimin/route', 1),
('/mimin/user/*', '*', 'mimin/user', 1),
('/mimin/user/create', 'create', 'mimin/user', 1),
('/mimin/user/delete', 'delete', 'mimin/user', 1),
('/mimin/user/index', 'index', 'mimin/user', 1),
('/mimin/user/update', 'update', 'mimin/user', 1),
('/mimin/user/view', 'view', 'mimin/user', 1),
('/note/*', '*', 'note', 1),
('/note/create', 'create', 'note', 1),
('/note/delete', 'delete', 'note', 1),
('/note/download', 'download', 'note', 1),
('/note/index', 'index', 'note', 1),
('/note/update', 'update', 'note', 1),
('/note/view', 'view', 'note', 1),
('/paramfund/*', '*', 'paramfund', 1),
('/paramfund/create', 'create', 'paramfund', 1),
('/paramfund/delete', 'delete', 'paramfund', 1),
('/paramfund/export-excel', 'export-excel', 'paramfund', 1),
('/paramfund/export-pdf', 'export-pdf', 'paramfund', 1),
('/paramfund/get-emiten', 'get-emiten', 'paramfund', 1),
('/paramfund/index', 'index', 'paramfund', 1),
('/paramfund/update', 'update', 'paramfund', 1),
('/paramfund/view', 'view', 'paramfund', 1),
('/pembelian/*', '*', 'pembelian', 1),
('/pembelian/create', 'create', 'pembelian', 1),
('/pembelian/delete', 'delete', 'pembelian', 1),
('/pembelian/get-emiten', 'get-emiten', 'pembelian', 1),
('/pembelian/get-securitas', 'get-securitas', 'pembelian', 1),
('/pembelian/index', 'index', 'pembelian', 1),
('/pembelian/update', 'update', 'pembelian', 1),
('/pembelian/view', 'view', 'pembelian', 1),
('/securitas/*', '*', 'securitas', 1),
('/securitas/create', 'create', 'securitas', 1),
('/securitas/delete', 'delete', 'securitas', 1),
('/securitas/export-excel', 'export-excel', 'securitas', 1),
('/securitas/export-pdf', 'export-pdf', 'securitas', 1),
('/securitas/index', 'index', 'securitas', 1),
('/securitas/update', 'update', 'securitas', 1),
('/securitas/view', 'view', 'securitas', 1),
('/site/*', '*', 'site', 0),
('/site/about', 'about', 'site', 0),
('/site/captcha', 'captcha', 'site', 0),
('/site/contact', 'contact', 'site', 0),
('/site/error', 'error', 'site', 0),
('/site/index', 'index', 'site', 0),
('/site/login', 'login', 'site', 0),
('/site/logout', 'logout', 'site', 0),
('/site/profile', 'profile', 'site', 0),
('/site/request-password-reset', 'request-password-reset', 'site', 0),
('/site/reset-password', 'reset-password', 'site', 0),
('/site/signup', 'signup', 'site', 0);

-- --------------------------------------------------------

--
-- Table structure for table `securitas`
--

CREATE TABLE IF NOT EXISTS `securitas` (
  `KODE` varchar(8) NOT NULL,
  `NAMA` varchar(30) NOT NULL,
  `ALAMAT` varchar(50) NOT NULL,
  `TELP` varchar(15) NOT NULL,
  `CP` varchar(20) NOT NULL,
  `HP` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `securitas`
--

INSERT INTO `securitas` (`KODE`, `NAMA`, `ALAMAT`, `TELP`, `CP`, `HP`) VALUES
('KPK', 'Komisi Pemberantasan Korupsi', 'Jl Pancoran Timur 2 - Jakarta Selatan', '021777777', 'Junaidi', '082232319321'),
('NMQ', 'Nuansa Madinatul Qu''ran', 'Jl Cepit Raya No 12 Kav 19 Kp Sawah', '0217526261', 'Hafid Mukhlasin', '081559915720');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `auth_key` varchar(32) COLLATE utf8_unicode_ci NOT NULL,
  `password_hash` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password_reset_token` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `status` smallint(6) NOT NULL DEFAULT '10',
  `created_at` int(11) NOT NULL,
  `updated_at` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `auth_key`, `password_hash`, `password_reset_token`, `email`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Admin', 'A9NNIGDc36nAQUiQVbMe3CR9xZ_8x489', '$2y$13$h.BsTjvVcQsc60Qr/QlSyeJ4pmI8Bi71B9NrK420Y9rD.6DWgJPo6', NULL, 'admin2@gmail.com', 1, 1444548165, 1445763432);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `asset`
--
ALTER TABLE `asset`
  ADD PRIMARY KEY (`TGL`);

--
-- Indexes for table `assetat`
--
ALTER TABLE `assetat`
  ADD PRIMARY KEY (`TGL`);

--
-- Indexes for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
  ADD PRIMARY KEY (`item_name`,`user_id`);

--
-- Indexes for table `auth_item`
--
ALTER TABLE `auth_item`
  ADD PRIMARY KEY (`name`), ADD KEY `rule_name` (`rule_name`), ADD KEY `idx-auth_item-type` (`type`);

--
-- Indexes for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
  ADD PRIMARY KEY (`parent`,`child`), ADD KEY `child` (`child`);

--
-- Indexes for table `auth_rule`
--
ALTER TABLE `auth_rule`
  ADD PRIMARY KEY (`name`);

--
-- Indexes for table `detemiten`
--
ALTER TABLE `detemiten`
  ADD PRIMARY KEY (`EMITEN_KODE`,`TGL`);

--
-- Indexes for table `emiten`
--
ALTER TABLE `emiten`
  ADD PRIMARY KEY (`KODE`);

--
-- Indexes for table `indikator`
--
ALTER TABLE `indikator`
  ADD PRIMARY KEY (`TGL`,`NAMA`);

--
-- Indexes for table `komisi`
--
ALTER TABLE `komisi`
  ADD PRIMARY KEY (`KOM_BELI`);

--
-- Indexes for table `lotshare`
--
ALTER TABLE `lotshare`
  ADD PRIMARY KEY (`JML_LBRSAHAM`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`), ADD KEY `parent` (`parent`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `note`
--
ALTER TABLE `note`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `paramfund`
--
ALTER TABLE `paramfund`
  ADD PRIMARY KEY (`EMITEN_KODE`,`TAHUN`,`TRIWULAN`);

--
-- Indexes for table `pembelian`
--
ALTER TABLE `pembelian`
  ADD PRIMARY KEY (`NOMOR`), ADD KEY `FK_emiten_pembelian` (`EMITEN_KODE`), ADD KEY `FK_securitas_pembelian` (`SECURITAS_KODE`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`name`), ADD KEY `idx-auth_item-type` (`type`);

--
-- Indexes for table `securitas`
--
ALTER TABLE `securitas`
  ADD PRIMARY KEY (`KODE`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `username` (`username`), ADD UNIQUE KEY `email` (`email`), ADD UNIQUE KEY `password_reset_token` (`password_reset_token`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `note`
--
ALTER TABLE `note`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `auth_assignment`
--
ALTER TABLE `auth_assignment`
ADD CONSTRAINT `auth_assignment_ibfk_1` FOREIGN KEY (`item_name`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `auth_item`
--
ALTER TABLE `auth_item`
ADD CONSTRAINT `auth_item_ibfk_1` FOREIGN KEY (`rule_name`) REFERENCES `auth_rule` (`name`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `auth_item_child`
--
ALTER TABLE `auth_item_child`
ADD CONSTRAINT `auth_item_child_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE,
ADD CONSTRAINT `auth_item_child_ibfk_2` FOREIGN KEY (`child`) REFERENCES `auth_item` (`name`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `detemiten`
--
ALTER TABLE `detemiten`
ADD CONSTRAINT `FK_emiten_detemiten` FOREIGN KEY (`EMITEN_KODE`) REFERENCES `emiten` (`KODE`);

--
-- Constraints for table `menu`
--
ALTER TABLE `menu`
ADD CONSTRAINT `menu_ibfk_1` FOREIGN KEY (`parent`) REFERENCES `menu` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `paramfund`
--
ALTER TABLE `paramfund`
ADD CONSTRAINT `FK_emiten_paramfund` FOREIGN KEY (`EMITEN_KODE`) REFERENCES `emiten` (`KODE`);

--
-- Constraints for table `pembelian`
--
ALTER TABLE `pembelian`
ADD CONSTRAINT `FK_emiten_pembelian` FOREIGN KEY (`EMITEN_KODE`) REFERENCES `emiten` (`KODE`),
ADD CONSTRAINT `FK_securitas_pembelian` FOREIGN KEY (`SECURITAS_KODE`) REFERENCES `securitas` (`KODE`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
